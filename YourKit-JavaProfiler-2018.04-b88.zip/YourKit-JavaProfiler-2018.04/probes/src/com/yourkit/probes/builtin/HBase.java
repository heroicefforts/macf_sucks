/*
  Copyright (c) 2003-2018, YourKit
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

  * Neither the name of YourKit nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY YOURKIT "AS IS" AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL YOURKIT BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.yourkit.probes.builtin;

import com.yourkit.probes.*;
import com.yourkit.util.Strings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.yourkit.probes.ReflectionUtil.callMethod0String;
import static com.yourkit.probes.ReflectionUtil.getFieldValue;

public class HBase {
  public static final String TABLE_NAME = "HBase";

  private static final class HBaseTable extends Table {
    private final StringColumn myType = new StringColumn("Type");
    private final StringColumn myDetail = new StringColumn("Detail");

    public HBaseTable() {
      super(Processes.class, TABLE_NAME, Table.MASK_FOR_LASTING_EVENTS);
    }
  }
  private static final HBaseTable T_HBASE = new HBaseTable();

  private static final ThreadLocal<boolean[]> ourInsideTopCall = new ThreadLocal<boolean[]>() {
    @Override
    protected boolean[] initialValue() {
      return new boolean[1];
    }
  };

  // HTable

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HTable:put(org.apache.hadoop.hbase.client.Put)",
    "org.apache.hadoop.hbase.client.HTable:checkAndPut(*)"
  })
  public static final class Put {
    public static int onEnter(
      @This final Object table,
      @Param(1) final Object param1,
      @Param(5) final Object param5,
      @Param(6) final Object param6
    ) {
      final Object operation = param6 != null ? param6 : param5 != null ? param5 : param1;
      if (operation == null) {
        return Table.NO_ROW;
      }

      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "put");
      T_HBASE.myDetail.setValue(row, getOperationDetail(table, operation));
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HTable:get(org.apache.hadoop.hbase.client.Get)",
    "org.apache.hadoop.hbase.client.HTable:exists(org.apache.hadoop.hbase.client.Get)"
  })
  public static final class Get {
    public static int onEnter(@This final Object table, @Param(1) final Object param) {
      if (param == null) {
        return Table.NO_ROW;
      }
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "get");
      T_HBASE.myDetail.setValue(row, getQueryDetail(table, param));
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern("org.apache.hadoop.hbase.client.HTable:append(org.apache.hadoop.hbase.client.Append)")
  public static final class Append {
    public static int onEnter(@This final Object table, @Param(1) final Object param) {
      if (param == null) {
        return Table.NO_ROW;
      }
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "append");
      T_HBASE.myDetail.setValue(row, getOperationDetail(table, param));
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HTable:delete(org.apache.hadoop.hbase.client.Delete)",
    "org.apache.hadoop.hbase.client.HTable:checkAndDelete(*)"
  })
  public static final class Delete {
    public static int onEnter(@This final Object table, @Param(1) final Object param1, @Param(5) final Object param5, @Param(6) final Object param6) {
      final Object operation = param6 != null ? param6 : param5 != null ? param5 : param1;
      if (operation == null) {
        return Table.NO_ROW;
      }
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "delete");
      T_HBASE.myDetail.setValue(row, getOperationDetail(table, operation));
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HTable:mutateRow(org.apache.hadoop.hbase.client.RowMutations)",
    "org.apache.hadoop.hbase.client.HTable:checkAndMutate(*)"
  })
  public static final class MutateRow {
    public static int onEnter(@This final Object table, @Param(1) final Object param1, @Param(6) final Object param6) {
      final Object mutations = param6 != null ? param6 : param1;
      if (mutations == null) {
        return Table.NO_ROW;
      }
      final List list = getFieldValue(mutations, "mutations:Ljava/util/List;");
      final String detail;
      if (list == null) {
        detail = "<unknown>";
      }
      else {
        detail = "table=\"" + table2str(table) + "\" mutations=" + list.size();
      }

      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "mutateRow");
      T_HBASE.myDetail.setValue(row, detail);
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HTable:put(java.util.List)",
    "org.apache.hadoop.hbase.client.HTable:batch(java.util.List, Object[])",
    "org.apache.hadoop.hbase.client.HTable:batchCallback(java.util.List, Object[], org.apache.hadoop.hbase.client.coprocessor.Batch$Callback)"
  })
  public static final class Batch {
    public static int onEnter(@This final Object table, @Param(1) final List actions) {
      if (actions == null) {
        return Table.NO_ROW;
      }
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "batch");
      T_HBASE.myDetail.setValue(row, "table=\"" + table2str(table) + "\" batchSize=" + actions.size());
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HTable:increment(org.apache.hadoop.hbase.client.Increment)",
    "org.apache.hadoop.hbase.client.HTable:incrementColumnValue(byte[], byte[], byte[], long, org.apache.hadoop.hbase.client.Durability)"
  })
  public static final class Increment {
    public static int onEnter(@This final Object table, @MethodName final String methodName, @Param(1) final Object param1) {
      if (param1 == null) {
        return Table.NO_ROW;
      }
      final String detail;
      if ("increment".equals(methodName)) {
        detail = getOperationDetail(table, param1);
      }
      else {
        detail = "table=\"" + table2str(table) + "\" columns=1";
      }

      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "increment");
      T_HBASE.myDetail.setValue(row, detail);
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  /**
   * For Put, Append, Delete and Increment
   */
  @NotNull
  static String getOperationDetail(@NotNull final Object table, @NotNull final Object operation) {
    final Map<?, ? extends Collection> map = getFieldValue(operation.getClass().getSuperclass(), operation, "familyMap:Ljava/util/NavigableMap;", null);
    return getDetail(table, map);
  }

  /**
   * For Scan and Get
   */
  @NotNull
  static String getQueryDetail(@NotNull final Object table, @NotNull final Object operation) {
    final Map<?, ? extends Collection> map = getFieldValue(operation, "familyMap:Ljava/util/Map;");
    return getDetail(table, map);
  }

  @NotNull
  private static String getDetail(@NotNull final Object table, @Nullable final Map<?, ? extends Collection> map) {
    if (map == null) {
      return "<unknown>";
    }
    int size = 0;
    for (final Map.Entry<?, ? extends Collection> entry : map.entrySet()) {
      final Collection value = entry.getValue();
      size += value == null ? 1 : value.size();
    }
    return "table=\"" + table2str(table) + "\" columns=" + (size == 0 ? "<all>" : size);
  }

  // Job

  @MethodPattern("org.apache.hadoop.mapreduce.Job:waitForCompletion(boolean)")
  public static final class Job {
    public static int onEnter(@This final Object job) {
      final String name = callMethod0String(job, "getJobName");

      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "mapReduce");
      T_HBASE.myDetail.setValue(row, "job=\"" + Strings.notNull(name, "<unknown>") + "\"");
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.ClientScanner:loadCache()",
    "org.apache.hadoop.hbase.client.ClientSmallScanner:loadCache()",
    "org.apache.hadoop.hbase.client.ReversedClientScanner:loadCache()",
    "org.apache.hadoop.hbase.client.ClientSmallReversedScanner:loadCache()"
  })
  public static final class Scanner {
    public static int onEnter() {
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "scan");
      return row;
    }

    public static void onExit(
      @OnEnterResult final int row,
      @This final Object scanner,
      @ClassRef final Class aClass,
      @ThrownException final Throwable e
    ) {
      if (Table.shouldIgnoreRow(row)) {
        return;
      }
      T_HBASE.closeRow(row, e);
      try {
        final String name = aClass.getName();
        final Class clientScannerClass;
        if (name.equals("org.apache.hadoop.hbase.client.ClientScanner")) {
          clientScannerClass = aClass;
        }
        else if (name.equals("org.apache.hadoop.hbase.client.ClientSmallReversedScanner")) {
          clientScannerClass = aClass.getSuperclass().getSuperclass();
        }
        else {
          clientScannerClass = aClass.getSuperclass();
        }
        final Object scan = getFieldValue(clientScannerClass, scanner, "scan:Lorg/apache/hadoop/hbase/client/Scan;", null);
        final Object table = getFieldValue(clientScannerClass, scanner, "tableName:Lorg/apache/hadoop/hbase/TableName;", null);
        final String queryDetail = (scan != null && table != null) ? getQueryDetail(table, scan) : "";
        final List r = getFieldValue(clientScannerClass, scanner, "cache:Ljava/util/LinkedList;", null);
        final int rows = r == null ? 0 : r.size();
        T_HBASE.myDetail.setValue(row, queryDetail + " rows=" + rows);
      }
      catch (final Throwable ignored) {
      }
    }
  }

  // HBaseAdmin

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HBaseAdmin:createTable(org.apache.hadoop.hbase.HTableDescriptor, byte[][])",
    "org.apache.hadoop.hbase.client.HBaseAdmin:createTableAsync(org.apache.hadoop.hbase.HTableDescriptor, byte[][])",
    "org.apache.hadoop.hbase.client.HBaseAdmin:deleteTable(org.apache.hadoop.hbase.TableName)", // no Async version
    "org.apache.hadoop.hbase.client.HBaseAdmin:enableTable(org.apache.hadoop.hbase.TableName)",
    "org.apache.hadoop.hbase.client.HBaseAdmin:enableTableAsync(org.apache.hadoop.hbase.TableName)",
    "org.apache.hadoop.hbase.client.HBaseAdmin:disableTable(org.apache.hadoop.hbase.TableName)",
    "org.apache.hadoop.hbase.client.HBaseAdmin:disableTableAsync(org.apache.hadoop.hbase.TableName)"
  })
  public static final class TableOperations {
    public static int onEnter(@MethodName final String method, @Param(1) final Object param) {
      final boolean[] insideTopCall = ourInsideTopCall.get();
      if (insideTopCall[0]) {
        return Table.NO_ROW;
      }

      final String type = Strings.cutPostfix(method, "Async");
      final Object tableName;
      if (method.startsWith("createTable")) {
        tableName = param == null ? null : getFieldValue(param, "name:Lorg/apache/hadoop/hbase/TableName;");
      }
      else {
        tableName = param;
      }
      final String tableNameStr;
      if (tableName == null) {
        tableNameStr = "<unknown>";
      }
      else {
        tableNameStr = tableName.toString();
      }
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, type);
      T_HBASE.myDetail.setValue(row, "table=" + tableNameStr);
      insideTopCall[0] = true;
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      if (Table.shouldIgnoreRow(row)) {
        return;
      }
      ourInsideTopCall.get()[0] = false;
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HBaseAdmin:modifyColumn(org.apache.hadoop.hbase.TableName, org.apache.hadoop.hbase.HColumnDescriptor)",
    "org.apache.hadoop.hbase.client.HBaseAdmin:addColumn(org.apache.hadoop.hbase.TableName, org.apache.hadoop.hbase.HColumnDescriptor)"
  })
  public static final class ModifyAddColumn {
    public static int onEnter(
      @MethodName final String methodName,
      @Param(1) final Object tableName,
      @Param(2) final Object column
    ) {
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, methodName);
      T_HBASE.myDetail.setValue(row, "table=\"" + String.valueOf(tableName) + "\" columnFamily=\"" + columnDescriptor2str(column) + "\"");
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern({
    "org.apache.hadoop.hbase.client.HBaseAdmin:deleteColumn(org.apache.hadoop.hbase.TableName, byte[])",
    "org.apache.hadoop.hbase.client.HBaseAdmin:compact(org.apache.hadoop.hbase.TableName, byte[], boolean)"
  })
  public static final class AdminOperations {
    public static int onEnter(
      @MethodName final String methodName,
      @Param(1) final Object tableName,
      @Param(2) final byte[] column
    ) {
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, methodName);
      T_HBASE.myDetail.setValue(row, "table=\"" + String.valueOf(tableName) + "\" columnFamily=\"" + bytes2str(column)+"\"");
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  @MethodPattern("org.apache.hadoop.hbase.client.HBaseAdmin:snapshot(org.apache.hadoop.hbase.protobuf.generated.HBaseProtos$SnapshotDescription)")
  public static final class Snapshot {
    public static int onEnter(@Param(1) final Object description) {
      final int row = T_HBASE.createRow();
      T_HBASE.myType.setValue(row, "snapshot");
      T_HBASE.myDetail.setValue(
        row,
        "table=\"" + callMethod0String(description, "getTable") +
        "\" snapshotName=\"" + callMethod0String(description, "getName") + "\""
      );
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException final Throwable e) {
      T_HBASE.closeRow(row, e);
    }
  }

  static String table2str(final Object table) {
    if (table == null) {
      return "<unknown>";
    }
    final String tableToStr = table.toString();
    final int endIndex = tableToStr.lastIndexOf(';');
    return endIndex < 1 ? tableToStr : tableToStr.substring(0, endIndex);
  }

  static String columnDescriptor2str(final Object columnDescriptor) {
    if (columnDescriptor == null) {
      return "<unknown>";
    }
    return bytes2str(getFieldValue(columnDescriptor, "name:[B"));
  }

  static String bytes2str(final Object bytes) {
    if (!(bytes instanceof byte[])) {
      return "<unknown>";
    }
    final byte[] asArray = (byte[])bytes;
    try {
      return asArray.length == 0 ? "" : Strings.createUtf8String(asArray);
    }
    catch (final Throwable ignored) {
      return "<unknown>";
    }
  }
}
